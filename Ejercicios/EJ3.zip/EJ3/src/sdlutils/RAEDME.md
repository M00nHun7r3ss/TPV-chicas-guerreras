This directory includes a set of classes to facilitate working with SDL. 


# SDLGame

TBD
  
# InputHandler

TBD

# Texture

TBD

# Font

TBD

# SoundEffect

TBD

# Music

TBD

# Random Number Generator

TBD

# Macros

TBD
