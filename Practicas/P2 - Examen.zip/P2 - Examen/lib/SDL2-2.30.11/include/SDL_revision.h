#ifdef SDL_VENDOR_INFO
#define SDL_REVISION SDL_VENDOR_INFO
#else
#define SDL_REVISION ""
#endif
#define SDL_REVISION_NUMBER 0
