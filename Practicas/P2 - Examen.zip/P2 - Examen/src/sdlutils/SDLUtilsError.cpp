// This file is part of the course TPV2@UCM - Samir Genaim

#include "SDLUtilsError.h"

const char *SDLUtilsError::_error = nullptr;

