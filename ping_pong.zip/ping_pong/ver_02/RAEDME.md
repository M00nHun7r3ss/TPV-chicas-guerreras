# PingPong v2

This version is as v1, but uses the input handler (controller) instead of passing the event to method handleEvent. 

GameObjects still have handleInput method, which can be eliminated and instead we handle input in the update method.
