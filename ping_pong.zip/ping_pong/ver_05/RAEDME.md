# PingPont v5

This version is like v4, but with factories. The file pingpong.cfg.json is an example of such file.

TODO: improve the error checks, for now it is quite simple.


