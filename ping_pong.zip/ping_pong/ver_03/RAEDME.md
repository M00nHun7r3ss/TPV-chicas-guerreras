# PingPong v3

This version is as v2, but has some more kinds of paddles and balls. What want to demonstrate here is that using multiple (implementation) inheritance can be complicated (e.g., when we try to inherit that update method from one kind of paddle but the update from another).
